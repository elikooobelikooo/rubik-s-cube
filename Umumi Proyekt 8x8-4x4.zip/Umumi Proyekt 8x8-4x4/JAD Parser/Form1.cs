﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//using System;

namespace JAD_Parser
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        ushort kicikKvadratForDovr = 0;
        uint boyukKvadratForDovr = 0; 
        int[] K = new int[16]; //kiçik kvadratı (4x4) saxlayan hissə
        string[] kvadratlar4x4 = new string[258]; //kiçik kvadratların stringlərini yadda saxlayan hissə
        int kvadratlar4x4_COUNTER; //her defe yuxardaki stringe yeni element elave etmek ucun counter (saygac)
        int[] K2 = new int[64]; //daha böyük kvadrat üçün olan (8x8) hissə
        string HTML_File;
        private void button1_Click(object sender, EventArgs e)
        {
            kvadratlar4x4_COUNTER = 0;
            HTML_File = "<style type=\"text/css\">\n" +
                    ".tg  {border-collapse:collapse;border-spacing:0;}\n" +
                    ".tg td{font-family:Arial, sans-serif;font-size:14px;padding:4px 9px;border-style:solid;border-width:1px;overflow:hidden;word-break:normal;border-color:black;}\n" +
                    ".tg .GREEN{font-weight:bold;background-color:#32cb00;border-color:inherit;text-align:center}\n" +
                    ".tg .RED{font-weight:bold;background-color:#fe0000;border-color:inherit;vertical-align:top}\n" +
                    "</style>\n";
            for (kicikKvadratForDovr = 0; kicikKvadratForDovr < 65535; kicikKvadratForDovr++)
            {//FOR UMUMI!!!

                bool SUITABLE = false, WHILE_TEST = true;
                int decimalNumber = kicikKvadratForDovr;
                int remainder;
                string result = string.Empty;
                for (int i = 0; i < 16; i++)
                {
                    if (kicikKvadratForDovr > 0)
                    {
                        remainder = decimalNumber % 2;
                        decimalNumber /= 2;
                        result = remainder.ToString() + result;
                    }
                    else
                    {
                        result = "0" + result;
                    }
                }

                for (int i = 0; i < 16; i++)
                {
                    K[i] = System.Convert.ToInt16(result[i].ToString());
                    //MessageBox.Show(baxilanElementler[i].ToString());
                }
                while (WHILE_TEST)
                {
                    if ((K[0] + K[1] + K[4] + K[5]) % 2 == 0) break;
                    if ((K[0] + K[2] + K[8] + K[10]) % 2 == 0) break;
                    if ((K[0] + K[3] + K[12] + K[15]) % 2 == 0) break;
                    if ((K[2] + K[3] + K[6] + K[7]) % 2 == 0) break;
                    if ((K[8] + K[9] + K[12] + K[13]) % 2 == 0) break;
                    if ((K[10] + K[11] + K[14] + K[15]) % 2 == 0) break;
                    if ((K[1] + K[3] + K[9] + K[11]) % 2 == 0) break;
                    if ((K[4] + K[6] + K[12] + K[14]) % 2 == 0) break;
                    if ((K[5] + K[7] + K[13] + K[15]) % 2 == 0) break;
                    if ((K[5] + K[6] + K[9] + K[10]) % 2 == 0) break;
                    if ((K[4] + K[7] + K[8] + K[11]) % 2 == 0) break;
                    if ((K[1] + K[2] + K[13] + K[14]) % 2 == 0) break;
                    WHILE_TEST = false;
                    SUITABLE = true;
                }

                if (SUITABLE)
                {
                    kvadratlar4x4[kvadratlar4x4_COUNTER] = result;
                    kvadratlar4x4_COUNTER++;
                    //MessageBox.Show(result);
//                    richTextBox1.Text += result + '\n';
                    
                    //HTML STRING INE YAZILMA PROSESI
                    HTML_File += "\n<table class=\"tg\">";
                    for (int a = 0; a < 4; a++)
                    {
                        HTML_File+="<tr>";
                        for (int b = 0; b < 4; b++)
                        {
                            if (result[a * 4 + b] == '0')
                            {
                                HTML_File += "<td class=\"RED\">-</td>";
                            }
                            else if (result[a * 4 + b] == '1')
                            {
                                HTML_File += "<td class=\"GREEN\">+</td>";
                            }
                        }
                        HTML_File+="</tr>";
                    }
                    HTML_File+="</table><br>\n";
                }
                
                //            string binary = Convert.ToString(kicikKvadratForDovr, 2);
                /// MessageBox.Show(result);

            }//FOR UMUMI SON!!!
            
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.Filter = "HTML files (*.html)|*.html|All files (*.*)|*.*";            
            saveFileDialog1.RestoreDirectory = true;

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
               System.IO.File.WriteAllText(saveFileDialog1.FileName, HTML_File);
            }
           // MessageBox.Show(kvadratlar4x4[255]); //debug
         //   MessageBox.Show(kvadratlar4x4[256]); //debug
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int label11 = 0;
            richTextBox1.Text = "";
            if (kvadratlar4x4_COUNTER == 0)
            {
                MessageBox.Show("Ilk kvadratlar mueyyen edilmeyib!!!");
            }
            else 
            {
               // uint a1, a2, a3, a4;
                string new8x8="";
                for (boyukKvadratForDovr = 0; boyukKvadratForDovr < 4000000000; boyukKvadratForDovr++)
                {
                 //   a1 = boyukKvadratForDovr % 256;
                 //   a2 = (boyukKvadratForDovr / 256) % 256;
                  //  a3 = ((boyukKvadratForDovr / 256) / 256) % 256;
                  //  a4 = (((boyukKvadratForDovr / 256) / 256) / 256) % 256;

                    new8x8 = kvadratlar4x4[boyukKvadratForDovr % 256] + 
                             kvadratlar4x4[(boyukKvadratForDovr / 256) % 256] +
                             kvadratlar4x4[((boyukKvadratForDovr / 256) / 256) % 256] +
                             kvadratlar4x4[(((boyukKvadratForDovr / 256) / 256) / 256) % 256];
                    bool SUITABLE = false, WHILE_TEST = true;
                    while (WHILE_TEST)
                    {

                        if (((int)new8x8[0] + (int)new8x8[16] + (int)new8x8[32] + (int)new8x8[48]) % 2 == 0) break;
                        if (((int)new8x8[5] + (int)new8x8[21] + (int)new8x8[37] + (int)new8x8[53]) % 2 == 0) break;
                        if (((int)new8x8[10] + (int)new8x8[26] + (int)new8x8[42] + (int)new8x8[58]) % 2 == 0) break;
                        if (((int)new8x8[15] + (int)new8x8[31] + (int)new8x8[47] + (int)new8x8[63]) % 2 == 0) break;
                        //++
                        if (((int)new8x8[1] + (int)new8x8[16] + (int)new8x8[37] + (int)new8x8[52]) % 2 == 0) break;
                        if (((int)new8x8[11] + (int)new8x8[26] + (int)new8x8[47] + (int)new8x8[62]) % 2 == 0) break;
                        if (((int)new8x8[4] + (int)new8x8[21] + (int)new8x8[32] + (int)new8x8[49]) % 2 == 0) break;
                        if (((int)new8x8[14] + (int)new8x8[31] + (int)new8x8[42] + (int)new8x8[59]) % 2 == 0) break;
                        //++
                        if (((int)new8x8[2] + (int)new8x8[16] + (int)new8x8[42] + (int)new8x8[56]) % 2 == 0) break;
                        if (((int)new8x8[7] + (int)new8x8[21] + (int)new8x8[47] + (int)new8x8[61]) % 2 == 0) break;
                        if (((int)new8x8[8] + (int)new8x8[26] + (int)new8x8[32] + (int)new8x8[50]) % 2 == 0) break;
                        if (((int)new8x8[13] + (int)new8x8[31] + (int)new8x8[37] + (int)new8x8[55]) % 2 == 0) break;
                        //++
                        if (((int)new8x8[3] + (int)new8x8[16] + (int)new8x8[47] + (int)new8x8[60]) % 2 == 0) break;
                        if (((int)new8x8[6] + (int)new8x8[21] + (int)new8x8[42] + (int)new8x8[57]) % 2 == 0) break;
                        if (((int)new8x8[9] + (int)new8x8[26] + (int)new8x8[37] + (int)new8x8[54]) % 2 == 0) break;
                        if (((int)new8x8[12] + (int)new8x8[31] + (int)new8x8[32] + (int)new8x8[51]) % 2 == 0) break;
                        //++
                        if (((int)new8x8[0] + (int)new8x8[17] + (int)new8x8[36] + (int)new8x8[53]) % 2 == 0) break;
                        if (((int)new8x8[10] + (int)new8x8[27] + (int)new8x8[46] + (int)new8x8[63]) % 2 == 0) break;
                        if (((int)new8x8[5] + (int)new8x8[20] + (int)new8x8[33] + (int)new8x8[48]) % 2 == 0) break;
                        if (((int)new8x8[15] + (int)new8x8[30] + (int)new8x8[43] + (int)new8x8[58]) % 2 == 0) break;
                        //++
                        if (((int)new8x8[4] + (int)new8x8[20] + (int)new8x8[36] + (int)new8x8[52]) % 2 == 0) break;
                        if (((int)new8x8[1] + (int)new8x8[17] + (int)new8x8[33] + (int)new8x8[49]) % 2 == 0) break;
                        if (((int)new8x8[11] + (int)new8x8[27] + (int)new8x8[43] + (int)new8x8[59]) % 2 == 0) break;
                        if (((int)new8x8[14] + (int)new8x8[30] + (int)new8x8[46] + (int)new8x8[62]) % 2 == 0) break;
                        //++
                        if (((int)new8x8[2] + (int)new8x8[17] + (int)new8x8[46] + (int)new8x8[61]) % 2 == 0) break;
                        if (((int)new8x8[8] + (int)new8x8[27] + (int)new8x8[36] + (int)new8x8[55]) % 2 == 0) break;
                        if (((int)new8x8[7] + (int)new8x8[20] + (int)new8x8[43] + (int)new8x8[56]) % 2 == 0) break;
                        if (((int)new8x8[13] + (int)new8x8[30] + (int)new8x8[33] + (int)new8x8[50]) % 2 == 0) break;
                        //++
                        if (((int)new8x8[3] + (int)new8x8[17] + (int)new8x8[43] + (int)new8x8[57]) % 2 == 0) break;
                        if (((int)new8x8[6] + (int)new8x8[20] + (int)new8x8[46] + (int)new8x8[60]) % 2 == 0) break;
                        if (((int)new8x8[9] + (int)new8x8[27] + (int)new8x8[33] + (int)new8x8[51]) % 2 == 0) break;
                        if (((int)new8x8[12] + (int)new8x8[30] + (int)new8x8[36] + (int)new8x8[54]) % 2 == 0) break;

                        if (((int)new8x8[0] + (int)new8x8[18] + (int)new8x8[40] + (int)new8x8[58]) % 2 == 0) break;
                        if (((int)new8x8[5] + (int)new8x8[23] + (int)new8x8[45] + (int)new8x8[63]) % 2 == 0) break;
                        if (((int)new8x8[10] + (int)new8x8[24] + (int)new8x8[34] + (int)new8x8[48]) % 2 == 0) break;
                        if (((int)new8x8[15] + (int)new8x8[29] + (int)new8x8[39] + (int)new8x8[53]) % 2 == 0) break;
                        //++
                        if (((int)new8x8[1] + (int)new8x8[18] + (int)new8x8[45] + (int)new8x8[62]) % 2 == 0) break;
                        if (((int)new8x8[4] + (int)new8x8[23] + (int)new8x8[40] + (int)new8x8[59]) % 2 == 0) break;
                        if (((int)new8x8[11] + (int)new8x8[24] + (int)new8x8[39] + (int)new8x8[52]) % 2 == 0) break;
                        if (((int)new8x8[14] + (int)new8x8[29] + (int)new8x8[34] + (int)new8x8[49]) % 2 == 0) break;
                        //++
                        if (((int)new8x8[0] + (int)new8x8[19] + (int)new8x8[44] + (int)new8x8[63]) % 2 == 0) break;
                        if (((int)new8x8[5] + (int)new8x8[22] + (int)new8x8[41] + (int)new8x8[58]) % 2 == 0) break;
                        if (((int)new8x8[10] + (int)new8x8[25] + (int)new8x8[38] + (int)new8x8[53]) % 2 == 0) break;
                        if (((int)new8x8[15] + (int)new8x8[28] + (int)new8x8[35] + (int)new8x8[48]) % 2 == 0) break;
                        //++
                        if (((int)new8x8[3] + (int)new8x8[19] + (int)new8x8[35] + (int)new8x8[51]) % 2 == 0) break;
                        if (((int)new8x8[6] + (int)new8x8[22] + (int)new8x8[38] + (int)new8x8[54]) % 2 == 0) break;
                        if (((int)new8x8[9] + (int)new8x8[25] + (int)new8x8[41] + (int)new8x8[57]) % 2 == 0) break;
                        if (((int)new8x8[12] + (int)new8x8[28] + (int)new8x8[44] + (int)new8x8[60]) % 2 == 0) break;
                        //++
                        if (((int)new8x8[1] + (int)new8x8[19] + (int)new8x8[41] + (int)new8x8[59]) % 2 == 0) break;
                        if (((int)new8x8[4] + (int)new8x8[22] + (int)new8x8[44] + (int)new8x8[62]) % 2 == 0) break;
                        if (((int)new8x8[11] + (int)new8x8[25] + (int)new8x8[35] + (int)new8x8[49]) % 2 == 0) break;
                        if (((int)new8x8[14] + (int)new8x8[28] + (int)new8x8[38] + (int)new8x8[52]) % 2 == 0) break;

                        if (((int)new8x8[2] + (int)new8x8[19] + (int)new8x8[38] + (int)new8x8[55]) % 2 == 0) break;
                        if (((int)new8x8[8] + (int)new8x8[25] + (int)new8x8[44] + (int)new8x8[61]) % 2 == 0) break;
                        if (((int)new8x8[13] + (int)new8x8[28] + (int)new8x8[41] + (int)new8x8[56]) % 2 == 0) break;
                        if (((int)new8x8[7] + (int)new8x8[22] + (int)new8x8[35] + (int)new8x8[50]) % 2 == 0) break;

                        if (((int)new8x8[2] + (int)new8x8[18] + (int)new8x8[34] + (int)new8x8[50]) % 2 == 0) break;
                        if (((int)new8x8[7] + (int)new8x8[23] + (int)new8x8[39] + (int)new8x8[55]) % 2 == 0) break;
                        if (((int)new8x8[8] + (int)new8x8[24] + (int)new8x8[40] + (int)new8x8[56]) % 2 == 0) break;
                        if (((int)new8x8[13] + (int)new8x8[29] + (int)new8x8[45] + (int)new8x8[61]) % 2 == 0) break;

                        if (((int)new8x8[3] + (int)new8x8[18] + (int)new8x8[39] + (int)new8x8[54]) % 2 == 0) break;
                        if (((int)new8x8[9] + (int)new8x8[24] + (int)new8x8[45] + (int)new8x8[60]) % 2 == 0) break;
                        if (((int)new8x8[6] + (int)new8x8[23] + (int)new8x8[34] + (int)new8x8[51]) % 2 == 0) break;
                        if (((int)new8x8[12] + (int)new8x8[29] + (int)new8x8[40] + (int)new8x8[57]) % 2 == 0) break;

                        
                        label11++;

                        label1.Text = label11.ToString();
                        //    MessageBox.Show(asd.ToString());
                        WHILE_TEST = false;
                        SUITABLE = true;
                    }

                    if (SUITABLE)
                    {
                        
                        richTextBox1.Text += new8x8+'\n';
                        File.AppendAllText(Application.StartupPath + @"\elmir.txt", new8x8+" say "+label11.ToString() + Environment.NewLine);
                        //System.IO.File.WriteAllText(@"C:\Users\Elmir Bashirli\Desktop\wp.txt"," ");
                        //System.IO.File.WriteAllText(@"C:\Users\Elmir Bashirli\Desktop\wp.txt", richTextBox1.Text + "\n\r");

                    }
                    //MessageBox.Show(new8x8);//debug

                  /*  for (int i = 0; i < 64; i++)
                    {
                        K2[i] = System.Convert.ToInt16(new8x8[i]);
                    }
                    */
                }


                return;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           // MessageBox.Show(Application.StartupPath);
            string path = Application.StartupPath+@"\elmir.txt";
            //MessageBox.Show(path);
            using (FileStream fs = new FileStream(path, FileMode.OpenOrCreate))
            {
                using (TextWriter tw = new StreamWriter(fs))
                {
                   
                }
            }
        }
    }
}
